function Initialize()
   tick, n, meters, coord, velocity, wind, windForce, flakes, rate, screenWidth = 0, 0, {}, {x = {}, y = {}}, {x = {}, y = {}}, 0, tonumber(SKIN:GetVariable('WindForce')), tonumber(SKIN:GetVariable('Flakes')), tonumber(SKIN:GetVariable('Rate')), tonumber(SKIN:GetVariable('SCREENAREAWIDTH'))
   termVelocity = math.ceil(SKIN:GetVariable('SCREENAREAHEIGHT') / (flakes * rate))
   math.randomseed(os.time())
   for i = 1, flakes do
      local meter = SKIN:GetMeter('F'..i)
      meters[i], coord.x[i], coord.y[i], velocity.x[i], velocity.y[i] = meter, 0, -40, 0, 0
      meter:Show()
   end
end

function Update()
   tick = (tick + 1) % rate
   if tick == 0 then
      n = n % flakes + 1
      velocity.x[n] = 0
      velocity.y[n] = termVelocity + math.random(0, 6)
      coord.x[n] = math.random(-wind * 20, screenWidth - wind * 20)
      coord.y[n] = -8
      wind = math.abs(wind) < 24 and wind + math.random(-windForce, windForce) or math.random(-18, 18)
   end
   for i = 1, flakes do
      velocity.x[i] = velocity.x[i] + math.random(-1, 1)
      coord.x[i] = coord.x[i] + velocity.x[i] + wind
      coord.y[i] = coord.y[i] + velocity.y[i]
      meters[i]:SetX(coord.x[i])
      meters[i]:SetY(coord.y[i])
   end
end
